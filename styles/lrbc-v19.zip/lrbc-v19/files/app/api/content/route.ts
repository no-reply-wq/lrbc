import { NextRequest, NextResponse } from 'next/server';
import { revalidateTag } from 'next/cache';
import { connectDB } from '@/lib/mongodb';
import ContentItem from '@/lib/models/ContentItem';
import { requireAdmin } from '@/lib/auth';
import { getContent } from '@/lib/content';

export async function GET() {
  return NextResponse.json(await getContent());
}

const okKey = (k: unknown): k is string => typeof k === 'string' && /^[\w.:\-\/]{1,160}$/.test(k);

// Save one value:  PUT { key, value }
export async function PUT(req: NextRequest) {
  const deny = requireAdmin(req); if (deny) return deny;
  try {
    const { key, value } = await req.json();
    if (!okKey(key) || typeof value !== 'string' || value.length > 20000) {
      return NextResponse.json({ error: 'Bad request' }, { status: 400 });
    }
    await connectDB();
    await ContentItem.findOneAndUpdate({ key }, { key, value }, { upsert: true, new: true });
    revalidateTag('content');
    return NextResponse.json({ ok: true });
  } catch (e) { return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

// Back to the original text/photo:  DELETE ?key=...
export async function DELETE(req: NextRequest) {
  const deny = requireAdmin(req); if (deny) return deny;
  try {
    const key = req.nextUrl.searchParams.get('key');
    if (!okKey(key)) return NextResponse.json({ error: 'Bad request' }, { status: 400 });
    await connectDB();
    await ContentItem.deleteOne({ key });
    revalidateTag('content');
    return NextResponse.json({ ok: true });
  } catch (e) { return NextResponse.json({ error: String(e) }, { status: 500 }); }
}
