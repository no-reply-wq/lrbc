import { unstable_cache } from 'next/cache';
import { connectDB } from '@/lib/mongodb';
import ContentItem from '@/lib/models/ContentItem';

export type ContentMap = Record<string, string>;

const load = unstable_cache(
  async (): Promise<ContentMap> => {
    await connectDB();
    const docs = await ContentItem.find().lean<{ key: string; value: string }[]>();
    const out: ContentMap = {};
    for (const d of docs) out[d.key] = d.value;
    return out;
  },
  ['lrbc-content'],
  { tags: ['content'], revalidate: 300 },
);

/** Every editable value, keyed by id. Never throws: if the database is unreachable the site shows its built-in defaults. */
export async function getContent(): Promise<ContentMap> {
  try { return await load(); } catch { return {}; }
}
