'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import dynamic from 'next/dynamic';

const EditorOverlay = dynamic(() => import('./EditorOverlay'), { ssr: false });

type Values = Record<string, string>;
type Ctx = {
  values: Values;
  editing: boolean;
  admin: boolean;
  setEditing: (v: boolean) => void;
  save: (key: string, value: string) => Promise<void>;
  reset: (key: string) => Promise<void>;
};

const CmsContext = createContext<Ctx>({
  values: {}, editing: false, admin: false,
  setEditing: () => {}, save: async () => {}, reset: async () => {},
});
export const useCms = () => useContext(CmsContext);

const EDIT_KEY = 'lrbc_edit_mode';

export default function ContentProvider({ initial, children }: { initial: Values; children: ReactNode }) {
  const [values, setValues] = useState<Values>(initial);
  const [admin, setAdmin] = useState(false);
  const [editing, setEditingState] = useState(false);

  // Is the person looking at the site the signed-in admin?
  useEffect(() => {
    let live = true;
    fetch('/api/auth/me', { cache: 'no-store' })
      .then((r) => r.json())
      .then((j) => {
        if (!live || !j?.admin) return;
        setAdmin(true);
        try { if (sessionStorage.getItem(EDIT_KEY) === '1') setEditingState(true); } catch { /* ignore */ }
      })
      .catch(() => {});
    return () => { live = false; };
  }, []);

  // New values arriving from the server (after a refresh) replace the starting ones.
  useEffect(() => { setValues(initial); }, [initial]);

  const setEditing = useCallback((v: boolean) => {
    setEditingState(v);
    try { sessionStorage.setItem(EDIT_KEY, v ? '1' : '0'); } catch { /* ignore */ }
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle('lrbc-editing', editing);
    return () => document.documentElement.classList.remove('lrbc-editing');
  }, [editing]);

  const save = useCallback(async (key: string, value: string) => {
    const res = await fetch('/api/content', {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }),
    });
    if (res.status === 401) throw new Error('Your session expired. Please sign in again.');
    if (!res.ok) throw new Error('Could not save. Please try again.');
    setValues((v) => ({ ...v, [key]: value }));
  }, []);

  const reset = useCallback(async (key: string) => {
    const res = await fetch(`/api/content?key=${encodeURIComponent(key)}`, { method: 'DELETE' });
    if (res.status === 401) throw new Error('Your session expired. Please sign in again.');
    if (!res.ok) throw new Error('Could not reset. Please try again.');
    setValues((v) => { const n = { ...v }; delete n[key]; return n; });
  }, []);

  const ctx = useMemo(() => ({ values, editing, admin, setEditing, save, reset }), [values, editing, admin, setEditing, save, reset]);

  return (
    <CmsContext.Provider value={ctx}>
      {children}
      {admin && <EditorOverlay />}
    </CmsContext.Provider>
  );
}
