'use client';

import { useEffect, useRef, useState } from 'react';
import { useCms } from './ContentProvider';
import { compressImage } from '@/lib/imageCompress';

type Target = { kind: 'text' | 'img' | 'link'; id: string; def: string; labelId?: string; labelDef?: string; reload?: boolean };

export default function EditorOverlay() {
  const { editing, setEditing, values, save, reset } = useCms();
  const [t, setT] = useState<Target | null>(null);
  const [val, setVal] = useState('');
  const [lab, setLab] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // pick what to edit by clicking it on the page
  useEffect(() => {
    if (!editing) { setT(null); return; }
    const onClick = (e: MouseEvent) => {
      const el = e.target as Element | null;
      if (!el || el.closest('[data-cms-panel]') || el.closest('.lrbc-cms-hide')) return;
      const hit = el.closest('[data-cms]') as HTMLElement | null;
      if (!hit) return;
      e.preventDefault(); e.stopPropagation();
      const kind = hit.dataset.cms as Target['kind'];
      const id = hit.dataset.id ?? '';
      const def = hit.dataset.def ?? '';
      const labelId = hit.dataset.labelId; const labelDef = hit.dataset.labelDef ?? '';
      setT({ kind, id, def, labelId, labelDef, reload: hit.dataset.reload === '1' });
      setVal(id in values ? values[id] : def);
      setLab(labelId ? (labelId in values ? values[labelId] : labelDef) : '');
      setMsg(null);
    };
    document.addEventListener('click', onClick, true);
    return () => document.removeEventListener('click', onClick, true);
  }, [editing, values]);

  async function doSave(v = val) {
    if (!t) return;
    setBusy(true); setMsg(null);
    try {
      await save(t.id, v);
      if (t.labelId) await save(t.labelId, lab);
      setMsg({ ok: true, text: t.reload ? 'Saved — refreshing…' : 'Saved — live on the website.' });
      if (t.reload) setTimeout(() => window.location.reload(), 500);
    }
    catch (e) { setMsg({ ok: false, text: (e as Error).message }); }
    setBusy(false);
  }
  async function doReset() {
    if (!t) return;
    setBusy(true); setMsg(null);
    try {
      await reset(t.id); if (t.labelId) { await reset(t.labelId); setLab(t.labelDef ?? ''); }
      setVal(t.def); setMsg({ ok: true, text: t.reload ? 'Back to the original — refreshing…' : 'Back to the original.' });
      if (t.reload) setTimeout(() => window.location.reload(), 500);
    }
    catch (e) { setMsg({ ok: false, text: (e as Error).message }); }
    setBusy(false);
  }
  async function onFile(f: File | undefined) {
    if (!f || !t) return;
    setBusy(true); setMsg(null);
    try {
      const small = await compressImage(f);
      const form = new FormData(); form.append('file', small);
      const res = await fetch('/api/upload', { method: 'POST', body: form });
      if (res.status === 401) throw new Error('Your session expired. Please sign in again.');
      if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || 'Upload failed.');
      const { url } = await res.json();
      setVal(url);
      await save(t.id, url);
      setMsg({ ok: true, text: 'Photo uploaded — live on the website.' });
    } catch (e) { setMsg({ ok: false, text: (e as Error).message }); }
    setBusy(false);
    if (fileRef.current) fileRef.current.value = '';
  }
  async function logout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    try { sessionStorage.removeItem('lrbc_edit_mode'); } catch { /* ignore */ }
    window.location.reload();
  }

  const label = t?.kind === 'img' ? 'Photo' : t?.kind === 'link' ? 'Link address' : 'Text';

  return (
    <>
      <div data-cms-panel role="toolbar" aria-label="Website editor" className="lrbc-cms-bar">
        <button type="button" onClick={() => setEditing(!editing)} className={`lrbc-cms-btn ${editing ? 'on' : ''}`}>
          {editing ? '● Editing — click to stop' : '✎ Edit this page'}
        </button>
        <a href="/12245-admin" className="lrbc-cms-btn ghost">Dashboard</a>
        <button type="button" onClick={logout} className="lrbc-cms-btn ghost">Log out</button>
      </div>

      {editing && !t && (
        <p data-cms-panel className="lrbc-cms-hint">Click any dashed text, photo or link to change it.</p>
      )}

      {editing && t && (
        <div data-cms-panel role="dialog" aria-label={`Edit ${label}`} className="lrbc-cms-panel">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-sm font-semibold">Edit {label.toLowerCase()}</p>
              <p className="mt-0.5 break-all font-mono text-[10px] text-neutral-500">{t.id}</p>
            </div>
            <button type="button" onClick={() => setT(null)} aria-label="Close" className="text-xl leading-none text-neutral-500 hover:text-neutral-900">×</button>
          </div>

          {t.kind === 'text' && (
            <textarea value={val} onChange={(e) => setVal(e.target.value)} rows={6} className="lrbc-cms-input mt-3" />
          )}
          {t.kind === 'link' && (
            <div className="mt-3 space-y-2">
              {t.labelId && (<><label className="text-xs font-medium text-neutral-600">Words shown</label><input value={lab} onChange={(e) => setLab(e.target.value)} className="lrbc-cms-input" /></>)}
              <label className="text-xs font-medium text-neutral-600">Goes to (page or web address)</label>
              <input value={val} onChange={(e) => setVal(e.target.value)} className="lrbc-cms-input" placeholder="/contact or https://…" />
            </div>
          )}
          {t.kind === 'img' && (
            <div className="mt-3 space-y-3">
              {val && <img src={val} alt="" className="max-h-40 w-full rounded-lg border object-contain" />}
              <input ref={fileRef} type="file" accept="image/*" onChange={(e) => onFile(e.target.files?.[0])} className="block w-full text-xs" />
              <input value={val} onChange={(e) => setVal(e.target.value)} className="lrbc-cms-input" placeholder="…or paste an image address (URL)" />
            </div>
          )}

          {msg && <p role="status" className={`mt-3 text-xs ${msg.ok ? 'text-emerald-700' : 'text-red-600'}`}>{msg.text}</p>}

          <div className="mt-4 flex flex-wrap gap-2">
            <button type="button" disabled={busy} onClick={() => doSave()} className="lrbc-cms-btn on">{busy ? 'Please wait…' : 'Save'}</button>
            <button type="button" disabled={busy} onClick={doReset} className="lrbc-cms-btn ghost">Back to original</button>
          </div>
        </div>
      )}
    </>
  );
}
