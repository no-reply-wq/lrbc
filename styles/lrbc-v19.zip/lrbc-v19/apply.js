// Copies the updated files into the project. No backups are created.
// Run from the project root (folder with package.json):  node lrbc-v19/apply.js
const fs = require("fs"), path = require("path");
const root = process.cwd(), src = path.join(__dirname, "files");
if (!fs.existsSync(path.join(root, "package.json"))) { console.error("Run this from the project root (the folder that contains package.json)."); process.exit(1); }
let n = 0;
(function walk(d) {
  for (const e of fs.readdirSync(d, { withFileTypes: true })) {
    const p = path.join(d, e.name);
    if (e.isDirectory()) { walk(p); continue; }
    const rel = path.relative(src, p), dest = path.join(root, rel);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(p, dest); n++;
    console.log("  updated", rel.split(path.sep).join("/"));
  }
})(src);
console.log(`\nDone — ${n} files updated.`);

// Remind about the three new settings (never overwrites .env.local)
const envFile = path.join(root, ".env.local");
const have = fs.existsSync(envFile) ? fs.readFileSync(envFile, "utf8") : "";
const missing = ["ADMIN_EMAIL", "ADMIN_PASSWORD", "AUTH_SECRET"].filter((k) => !new RegExp("^" + k + "=", "m").test(have));
if (missing.length) {
  console.log("\nNEXT: add these lines to .env.local (and to Vercel → Settings → Environment Variables):");
  for (const k of missing) console.log("  " + k + "=");
  console.log("  (ADMIN_EMAIL = your login email, ADMIN_PASSWORD = a strong password, AUTH_SECRET = any long random text, 24+ characters)");
} else console.log("\nAdmin settings found in .env.local.");
